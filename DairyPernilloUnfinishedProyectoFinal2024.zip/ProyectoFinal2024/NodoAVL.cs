﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal2024
{
        // Nodo del árbol AVL
        public class NodoAVL
        {
            public Equipo Equipo { get; set; }
            public NodoAVL Izquierdo { get; set; }
            public NodoAVL Derecho { get; set; }
            public int Altura { get; set; }

            public NodoAVL(Equipo equipo)
            {
                Equipo = equipo;
                Izquierdo = null;
                Derecho = null;
                Altura = 1; // Altura inicial
            }
        }
    }

//REVISAR DETALLES ADICIONALES Y LAS DEPENDENCIAS DE LAS PRUEBAS UNITARIAS. CREAR INTERFACE PARA PODER SER USADO EN EL PROYECTO FINAL. FECHA de ultima actualizacion: 02/06/2024 by Dairy Pernillo
