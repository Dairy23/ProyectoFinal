﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//REVISAR DETALLES ADICIONALES Y LAS DEPENDENCIAS DE LAS PRUEBAS UNITARIAS. CREAR INTERFACE PARA PODER SER USADO EN EL PROYECTO FINAL. FECHA de ultima actualizacion: 02/06/2024 by Dairy Pernillo

namespace ProyectoFinal2024
{
    public class HashTable
    {
        public const int Size = 101;
        public LinkedList<Partido>[] table;

        public HashTable()
        {
            table = new LinkedList<Partido>[Size];
            for (int i = 0; i < Size; i++)
            {
                table[i] = new LinkedList<Partido>();
            }
        }

        public int HashFunction(string key) => Math.Abs(key.GetHashCode()) % Size;

        public void Insertar(string key, Partido partido)
        {
            int hash = HashFunction(key);
            table[hash].AddLast(partido);
        }

        public Partido Buscar(string key)
        {
            int hash = HashFunction(key);
            foreach (Partido partido in table[hash])
            {
                if (partido.Id == key)
                    return partido;
            }
            return null;
        }
    }
}