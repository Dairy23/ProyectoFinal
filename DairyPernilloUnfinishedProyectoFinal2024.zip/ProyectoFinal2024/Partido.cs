﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal2024
{
    // Clase Partido
    public class Partido
    {
        public string Id { get; set; }
        public Equipo EquipoLocal { get; set; }
        public Equipo EquipoVisitante { get; set; }
        public DateTime Fecha { get; set; }
        public int GolesLocal { get; set; } // Agrega la propiedad para registrar los goles del equipo local
        public int GolesVisitante { get; set; } // Agrega la propiedad para registrar los goles del equipo visitante

        public Partido(string id, Equipo local, Equipo visitante, DateTime fecha)
        {
            Id = id;
            EquipoLocal = local;
            EquipoVisitante = visitante;
            Fecha = fecha;
        }

        // Método para registrar el resultado del partido
        public void RegistrarResultado(int golesLocal, int golesVisitante)
        {
            GolesLocal = golesLocal;
            GolesVisitante = golesVisitante;
        }
    }

// Clase para gestionar la tabla hash
public class TablaHash
    {
        private const int Tamaño = 100;
        private List<Partido>[] tabla;

        public TablaHash()
        {
            tabla = new List<Partido>[Tamaño];
            for (int i = 0; i < Tamaño; i++)
            {
                tabla[i] = new List<Partido>();
            }
        }

        private int HashFunc(string clave)
        {
            int hash = 0;
            foreach (char c in clave)
            {
                hash += c;
            }
            return hash % Tamaño;
        }

        public void Insertar(Partido partido)
        {
            int indice = HashFunc(partido.Id);
            tabla[indice].Add(partido);
        }

        public Partido Buscar(string id)
        {
            int indice = HashFunc(id);
            foreach (var partido in tabla[indice])
            {
                if (partido.Id.Equals(id, StringComparison.OrdinalIgnoreCase))
                    return partido;
            }
            return null;
        }

        public void Eliminar(string id)
        {
            int indice = HashFunc(id);
            tabla[indice].RemoveAll(p => p.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
        }
    }
}