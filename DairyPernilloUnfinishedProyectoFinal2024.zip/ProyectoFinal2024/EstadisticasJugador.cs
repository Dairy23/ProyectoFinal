﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//REVISAR DETALLES ADICIONALES Y LAS DEPENDENCIAS DE LAS PRUEBAS UNITARIAS. CREAR INTERFACE PARA PODER SER USADO EN EL PROYECTO FINAL. FECHA de ultima actualizacion: 02/06/2024 by Dairy Pernillo

namespace ProyectoFinal2024
{
    // Clase EstadísticasJugador
    public class EstadísticasJugador
    {
        public Jugador Jugador { get; }
        public int MinutosJugados { get; private set; }
        public int Goles { get; private set; }
        public int Asistencias { get; private set; }
        public int TarjetasAmarillas { get; set; }
        public int TarjetasRojas { get; set; }

        // Constructor que acepta un objeto Jugador
        public EstadísticasJugador(Jugador jugador)
        {
            Jugador = jugador;
            Goles = 0;
            Asistencias = 0;
            TarjetasAmarillas = 0;
            TarjetasRojas = 0;
        }

        // Método para actualizar las estadísticas
        public void ActualizarEstadisticas(int minutosJugados, int goles, int asistencias)
        {
            MinutosJugados = minutosJugados;
            Goles = goles;
            Asistencias = asistencias;
        }
    }
}
