﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//REVISAR DETALLES ADICIONALES Y LAS DEPENDENCIAS DE LAS PRUEBAS UNITARIAS. CREAR INTERFACE PARA PODER SER USADO EN EL PROYECTO FINAL. FECHA de ultima actualizacion: 02/06/2024 by Dairy Pernillo

namespace ProyectoFinal2024
{
    public class EstadísticasPartido
    {
        public Partido Partido { get; }
        public int GolesLocal { get; set; }
        public int GolesVisitante { get; set; }
        public int PosesionLocal { get; set; }
        public int PosesionVisitante { get; set; }
        public int TarjetasAmarillas { get; set; }
        public int TarjetasRojas { get; set; }

        public EstadísticasPartido(Partido partido)
        {
            Partido = partido;
            GolesLocal = 0;
            GolesVisitante = 0;
            PosesionLocal = 0;
            PosesionVisitante = 0;
            TarjetasAmarillas = 0;
            TarjetasRojas = 0;
        }

        // Método para actualizar la posesión del partido
        public void ActualizarPosesion(int posesionLocal, int posesionVisitante)
        {
            PosesionLocal = posesionLocal;
            PosesionVisitante = posesionVisitante;
        }
    }
}