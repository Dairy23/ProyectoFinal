﻿using ProyectoFinal2024;
using System;
//REVISAR DETALLES ADICIONALES Y LAS DEPENDENCIAS DE LAS PRUEBAS UNITARIAS. CREAR INTERFACE PARA PODER SER USADO EN EL PROYECTO FINAL. FECHA de ultima actualizacion: 02/06/2024 by Dairy Pernillo

public class ArbolAVL
{
    public NodoAVL raiz;

    public ArbolAVL()
    {
        raiz = null;
    }

    // Función auxiliar para obtener la altura de un nodo
    public int Altura(NodoAVL nodo)
    {
        return nodo == null ? 0 : nodo.Altura;
    }

    // Función auxiliar para obtener el balance de un nodo
    public int Balance(NodoAVL nodo)
    {
        return nodo == null ? 0 : Altura(nodo.Izquierdo) - Altura(nodo.Derecho);
    }

    // Rotación a la derecha
    public NodoAVL RotacionDerecha(NodoAVL y)
    {
        NodoAVL x = y.Izquierdo;
        NodoAVL T2 = x.Derecho;

        // Rotar
        x.Derecho = y;
        y.Izquierdo = T2;

        // Actualizar alturas
        y.Altura = Math.Max(Altura(y.Izquierdo), Altura(y.Derecho)) + 1;
        x.Altura = Math.Max(Altura(x.Izquierdo), Altura(x.Derecho)) + 1;

        return x;
    }

    // Rotación a la izquierda
    public NodoAVL RotacionIzquierda(NodoAVL x)
    {
        NodoAVL y = x.Derecho;
        NodoAVL T2 = y.Izquierdo;

        // Rotar
        y.Izquierdo = x;
        x.Derecho = T2;

        // Actualizar alturas
        x.Altura = Math.Max(Altura(x.Izquierdo), Altura(x.Derecho)) + 1;
        y.Altura = Math.Max(Altura(y.Izquierdo), Altura(y.Derecho)) + 1;

        return y;
    }

    // Inserción en el árbol AVL
    public void Insertar(Equipo equipo)
    {
        raiz = Insertar(raiz, equipo);
    }

    public NodoAVL Insertar(NodoAVL nodo, Equipo equipo)
    {
        if (nodo == null)
            return new NodoAVL(equipo);

        if (string.Compare(equipo.Nombre, nodo.Equipo.Nombre) < 0)
            nodo.Izquierdo = Insertar(nodo.Izquierdo, equipo);
        else if (string.Compare(equipo.Nombre, nodo.Equipo.Nombre) > 0)
            nodo.Derecho = Insertar(nodo.Derecho, equipo);
        else
            return nodo; // No se permiten nombres duplicados

        // Actualizar la altura del nodo ancestro
        nodo.Altura = 1 + Math.Max(Altura(nodo.Izquierdo), Altura(nodo.Derecho));

        // Obtener el balance del nodo ancestro para verificar si está balanceado
        int balance = Balance(nodo);

        // Cuatro casos de desbalance

        // Izquierda Izquierda
        if (balance > 1 && string.Compare(equipo.Nombre, nodo.Izquierdo.Equipo.Nombre) < 0)
            return RotacionDerecha(nodo);

        // Derecha Derecha
        if (balance < -1 && string.Compare(equipo.Nombre, nodo.Derecho.Equipo.Nombre) > 0)
            return RotacionIzquierda(nodo);

        // Izquierda Derecha
        if (balance > 1 && string.Compare(equipo.Nombre, nodo.Izquierdo.Equipo.Nombre) > 0)
        {
            nodo.Izquierdo = RotacionIzquierda(nodo.Izquierdo);
            return RotacionDerecha(nodo);
        }

        // Derecha Izquierda
        if (balance < -1 && string.Compare(equipo.Nombre, nodo.Derecho.Equipo.Nombre) < 0)
        {
            nodo.Derecho = RotacionDerecha(nodo.Derecho);
            return RotacionIzquierda(nodo);
        }

        return nodo;
    }

    // Método para buscar un equipo en el árbol AVL
    public Equipo Buscar(string nombre)
    {
        return Buscar(raiz, nombre);
    }

    public Equipo Buscar(NodoAVL nodo, string nombre)
    {
        if (nodo == null)
            return null;

        if (nombre.Equals(nodo.Equipo.Nombre, StringComparison.OrdinalIgnoreCase))
            return nodo.Equipo;

        if (string.Compare(nombre, nodo.Equipo.Nombre) < 0)
            return Buscar(nodo.Izquierdo, nombre);

        return Buscar(nodo.Derecho, nombre);
    }

    // Método para eliminar un equipo del árbol AVL
    public void Eliminar(string nombre)
    {
        raiz = Eliminar(raiz, nombre);
    }

    public NodoAVL Eliminar(NodoAVL nodo, string nombre)
    {
        if (nodo == null)
            return nodo;

        if (string.Compare(nombre, nodo.Equipo.Nombre) < 0)
            nodo.Izquierdo = Eliminar(nodo.Izquierdo, nombre);
        else if (string.Compare(nombre, nodo.Equipo.Nombre) > 0)
            nodo.Derecho = Eliminar(nodo.Derecho, nombre);
        else
        {
            if ((nodo.Izquierdo == null) || (nodo.Derecho == null))
            {
                NodoAVL temp = nodo.Izquierdo ?? nodo.Derecho;

                if (temp == null)
                {
                    temp = nodo;
                    nodo = null;
                }
                else
                    nodo = temp;
            }
            else
            {
                NodoAVL temp = MinValorNodo(nodo.Derecho);
                nodo.Equipo = temp.Equipo;
                nodo.Derecho = Eliminar(nodo.Derecho, temp.Equipo.Nombre);
            }
        }

        if (nodo == null)
            return nodo;

        nodo.Altura = Math.Max(Altura(nodo.Izquierdo), Altura(nodo.Derecho)) + 1;

        int balance = Balance(nodo);

        if (balance > 1 && Balance(nodo.Izquierdo) >= 0)
            return RotacionDerecha(nodo);

        if (balance > 1 && Balance(nodo.Izquierdo) < 0)
        {
            nodo.Izquierdo = RotacionIzquierda(nodo.Izquierdo);
            return RotacionDerecha(nodo);
        }

        if (balance < -1 && Balance(nodo.Derecho) <= 0)
            return RotacionIzquierda(nodo);

        if (balance < -1 && Balance(nodo.Derecho) > 0)
        {
            nodo.Derecho = RotacionDerecha(nodo.Derecho);
            return RotacionIzquierda(nodo);
        }

        return nodo;
    }

    public NodoAVL MinValorNodo(NodoAVL nodo)
    {
        NodoAVL actual = nodo;

        while (actual.Izquierdo != null)
            actual = actual.Izquierdo;

        return actual;
    }
}
