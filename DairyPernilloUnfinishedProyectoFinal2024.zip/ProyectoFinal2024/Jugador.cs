﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal2024
{

    public class Jugador
    {
        public string Nombre { get; set; }
        public Equipo Equipo { get; set; }
        public int Goles { get; private set; }
        public int Asistencias { get; private set; } 

        // Constructor para inicializar el jugador con su nombre y equipo
        public Jugador(string nombre, Equipo equipo)
        {
            Nombre = nombre;
            Equipo = equipo;
            Goles = 0; // Inicializa los goles en 0 al crear un nuevo jugador
            Asistencias = 0; // Inicializa las asistencias en 0 al crear un nuevo jugador
        }

        // Método para registrar un gol
        public void RegistrarGol()
        {
            Goles++; // Incrementa el contador de goles
        }

        // Método para registrar una asistencia
        public void RegistrarAsistencia()
        {
            Asistencias++; // Incrementa el contador de asistencias
        }
    }
    // Nodo para la lista enlazada
    public class NodoJugador
    {
        public Jugador Jugador { get; set; }
        public NodoJugador Siguiente { get; set; }

        public NodoJugador(Jugador jugador)
        {
            Jugador = jugador;
            Siguiente = null;
        }
    }

    // Lista Enlazada para gestionar los jugadores
    public class ListaEnlazadaJugadores
    {
        private NodoJugador cabeza;

        public ListaEnlazadaJugadores()
        {
            cabeza = null;
        }

        public void Insertar(Jugador jugador)
        {
            NodoJugador nuevoNodo = new NodoJugador(jugador);
            if (cabeza == null)
            {
                cabeza = nuevoNodo;
            }
            else
            {
                NodoJugador actual = cabeza;
                while (actual.Siguiente != null)
                {
                    actual = actual.Siguiente;
                }
                actual.Siguiente = nuevoNodo;
            }
        }

        public Jugador Buscar(string nombre)
        {
            NodoJugador actual = cabeza;
            while (actual != null)
            {
                if (actual.Jugador.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase))
                    return actual.Jugador;
                actual = actual.Siguiente;
            }
            return null;
        }

        public void Eliminar(string nombre)
        {
            if (cabeza == null)
                return;

            if (cabeza.Jugador.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase))
            {
                cabeza = cabeza.Siguiente;
                return;
            }

            NodoJugador actual = cabeza;
            while (actual.Siguiente != null && !actual.Siguiente.Jugador.Nombre.Equals(nombre, StringComparison.OrdinalIgnoreCase))
            {
                actual = actual.Siguiente;
            }

            if (actual.Siguiente != null)
            {
                actual.Siguiente = actual.Siguiente.Siguiente;
            }
        }
    }
}