﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal2024
{
    class Program
    {
        static void Main(string[] args)
        {
            // Crear instancias de las estructuras de datos
            ArbolAVL arbolEquipos = new ArbolAVL();
            TablaHash tablaPartidos = new TablaHash();
            ListaEnlazadaJugadores listaJugadores = new ListaEnlazadaJugadores();

            // Ejemplo: Insertar equipos en el árbol AVL
            arbolEquipos.Insertar(new Equipo("Equipo A"));
            arbolEquipos.Insertar(new Equipo("Equipo B"));
            arbolEquipos.Insertar(new Equipo("Equipo C"));

            // Ejemplo: Buscar un equipo en el árbol AVL
            Equipo equipoBuscado = arbolEquipos.Buscar("Equipo B");
            if (equipoBuscado != null)
                Console.WriteLine($"Equipo encontrado: {equipoBuscado.Nombre}");
            else
                Console.WriteLine("Equipo no encontrado.");

            // Ejemplo: Insertar un partido en la tabla hash
            Partido partido = new Partido("P001", new Equipo("Equipo A"), new Equipo("Equipo B"), DateTime.Now);
            tablaPartidos.Insertar(partido);

            // Ejemplo: Buscar un partido en la tabla hash
            Partido partidoBuscado = tablaPartidos.Buscar("P001");
            if (partidoBuscado != null)
                Console.WriteLine($"Partido encontrado: {partidoBuscado.EquipoLocal.Nombre} vs {partidoBuscado.EquipoVisitante.Nombre}");
            else
                Console.WriteLine("Partido no encontrado.");

            // Ejemplo: Insertar jugadores en la lista enlazada
            listaJugadores.Insertar(new Jugador("Jugador 1", new Equipo("Equipo A")));
            listaJugadores.Insertar(new Jugador("Jugador 2", new Equipo("Equipo B")));

            // Ejemplo: Buscar un jugador en la lista enlazada
            Jugador jugadorBuscado = listaJugadores.Buscar("Jugador 1");
            if (jugadorBuscado != null)
                Console.WriteLine($"Jugador encontrado: {jugadorBuscado.Nombre}");
            else
                Console.WriteLine("Jugador no encontrado.");

            // Ejemplo: Eliminar un equipo del árbol AVL
            arbolEquipos.Eliminar("Equipo B");

            // Ejemplo: Eliminar un partido de la tabla hash
            tablaPartidos.Eliminar("P001");

            // Ejemplo: Eliminar un jugador de la lista enlazada
            listaJugadores.Eliminar("Jugador 1");
        }
    }
}