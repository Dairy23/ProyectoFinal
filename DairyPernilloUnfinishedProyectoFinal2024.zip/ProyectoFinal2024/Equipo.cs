﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//REVISAR DETALLES ADICIONALES Y LAS DEPENDENCIAS DE LAS PRUEBAS UNITARIAS. CREAR INTERFACE PARA PODER SER USADO EN EL PROYECTO FINAL. FECHA de ultima actualizacion: 02/06/2024 by Dairy Pernillo


namespace ProyectoFinal2024
{
    // Clase Equipo
    public class Equipo
    {
        public string Nombre { get; set; }
        public int Puntos { get; set; }

        public Equipo(string nombre)
        {
            Nombre = nombre;
            Puntos = 0;
        }
    }
}
