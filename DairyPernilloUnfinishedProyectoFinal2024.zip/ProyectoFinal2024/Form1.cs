﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ProyectoFinal2024
{
    public partial class Form1 : Form
    {
        private ArbolAVL arbolEquipos; // Declarar arbolEquipos
        private ListBox lstEquipos;    // Declarar lstEquipos

        public Form1()
        {
            InitializeComponent();
            arbolEquipos = new ArbolAVL();
            lstEquipos = new ListBox(); // Inicializar lstEquipos (si no se hace en el Diseñador) Dairy recuerda hacer esta verificacion 
        }

        private void btnAgregarEquipo_Click(object sender, EventArgs e)
        {
            string nombreEquipo = txtNombreEquipo.Text;
            if (!string.IsNullOrEmpty(nombreEquipo))
            {
                arbolEquipos.Insertar(new Equipo(nombreEquipo));
                MessageBox.Show($"Equipo {nombreEquipo} agregado.");
                txtNombreEquipo.Clear();
                ActualizarListaEquipos();
            }
            else
            {
                MessageBox.Show("Por favor, introduce un nombre de equipo.");
            }
        }

        private void btnBuscarEquipo_Click(object sender, EventArgs e)
        {
            string nombreEquipo = txtNombreEquipo.Text;
            Equipo equipo = arbolEquipos.Buscar(nombreEquipo);
            if (equipo != null)
            {
                MessageBox.Show($"Equipo encontrado: {equipo.Nombre}");
            }
            else
            {
                MessageBox.Show("Equipo no encontrado.");
            }
        }

        private void ActualizarListaEquipos()
        {
            lstEquipos.Items.Clear();
            RecorrerInOrden(arbolEquipos.raiz);
        }

        private void RecorrerInOrden(NodoAVL nodo)
        {
            if (nodo == null) return;
            RecorrerInOrden(nodo.Izquierdo);
            lstEquipos.Items.Add(nodo.Equipo.Nombre);
            RecorrerInOrden(nodo.Derecho);
        }

        private void txtNombreEquipo_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
